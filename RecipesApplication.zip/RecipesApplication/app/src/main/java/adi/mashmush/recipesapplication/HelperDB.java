package adi.mashmush.recipesapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;


public class HelperDB  extends SQLiteOpenHelper {
    public static final String DB_FILE = "all_info.db";
    public static final String USERS_TABLE = "Users";
    public static final String USER_NAME = "UserName";
    public static final String USER_PWD = "UserPassword";
    public static final String USER_EMAIL = "UserEmail";
    public static final String USER_PHONE = "UserPhone";
    public static final String RECIPES_TABLE = "Recipes";
    public static final String RECIPE_NAME = "RecipeName";
    public static final String RECIPE_USER = "RecipeUser";
    public static final String RECIPE_LEVEL = "RecipeLevel";
    public static final String RECIPE_MAKING_TIME = "RecipeMakingTime";
    public static final String RECIPE_FOOD_TYPE = "RecipeFoodType";
    public static final String RECIPE_DESCRIPTION = "RecipeDescription";
    public static final String RECIPES_PICTURE = "Picture";


    public HelperDB(Context context) {
        super(context, DB_FILE, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String st = "CREATE TABLE IF NOT EXISTS " + USERS_TABLE;
        st += " ( " + USER_NAME + " TEXT, ";
        st += USER_PWD + " TEXT, ";
        st += USER_EMAIL + " TEXT, ";
        st += USER_PHONE + " TEXT);";
        db.execSQL(st);
        st = "CREATE TABLE IF NOT EXISTS " + RECIPES_TABLE;
        st += " ( " + RECIPE_NAME + " TEXT, ";
        st += RECIPE_USER + " TEXT, ";
        st += RECIPE_LEVEL + " TEXT, ";
        st += RECIPE_MAKING_TIME + " TEXT, ";
        st += RECIPE_FOOD_TYPE + " TEXT, ";
        st += RECIPES_PICTURE + " BLOB, ";
        st += RECIPE_DESCRIPTION + " TEXT);";
        db.execSQL(st);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(USER_NAME, user.getUserName());
        cv.put(USER_PWD, user.getPassword());
        cv.put(USER_EMAIL, user.getEmail());
        cv.put(USER_PHONE, user.getPhone());
        db.insert(USERS_TABLE, null, cv);
        db.close();
    }
    public void insertRecipe(Recipe recipe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(RECIPE_USER,recipe.getRecipeUser());
        cv.put(RECIPE_NAME, recipe.getRecipeName());
        cv.put(RECIPE_DESCRIPTION, recipe.getRecipeDescription());
        cv.put(RECIPE_LEVEL, recipe.getLevel());
        cv.put(RECIPE_FOOD_TYPE, recipe.getFoodType());
        cv.put(RECIPE_MAKING_TIME, recipe.getMakingTime());
        cv.put(RECIPES_PICTURE, getBytes(recipe.getImage()));
        db.insert(RECIPES_TABLE, null, cv);
        db.close();
    }

    public User isUserFound(String name, String password) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String s = USER_NAME + "=? AND " + USER_PWD + "=?";
        String[] sA = new String[]{name, password};

        Cursor cursor = sqLiteDatabase.query(USERS_TABLE, null, s, sA, null, null, null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0)
        {
            User user=new User();
            user.setUserName(cursor.getString((int) cursor.getColumnIndex(USER_NAME)));
            user.setPassword(cursor.getString((int) cursor.getColumnIndex(USER_PWD)));
            user.setEmail(cursor.getString((int) cursor.getColumnIndex(USER_EMAIL)));
            user.setPhone(cursor.getString((int) cursor.getColumnIndex(USER_PHONE)));
        return user;


        }
        else return null;
    }
    public boolean isUserNameFound(String name) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String s = USER_NAME + "=?";
        String[] sA = new String[]{name};
        Cursor cursor = sqLiteDatabase.query(USERS_TABLE, null, s, sA, null, null, null);
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }
    public boolean isRecipeFoundByUserName(String rName, String uName) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String s = RECIPE_NAME + "=? AND " + RECIPE_USER + "=?";
        String[] sA = new String[]{rName,uName};
        Cursor cursor = sqLiteDatabase.query(RECIPES_TABLE, null, s, sA, null, null, null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }
    public void deleteRecipe(String recipeToDelete, String uName){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String s = RECIPE_NAME + "=? AND " + RECIPE_USER + "=?";
        String[] sA = new String[]{recipeToDelete,uName};
        sqLiteDatabase.delete(RECIPES_TABLE,s,sA);
        sqLiteDatabase.close();

    }
    public ArrayList<Recipe>getMyRecipies(String currentUser){
        ArrayList<Recipe> arrayList= new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String selection = RECIPE_USER + " = ?";
        String[] selectionArgs = { currentUser };
        Cursor c = sqLiteDatabase.query( RECIPES_TABLE, null, selection, selectionArgs,        null,
                null,
                null
        );
        int col1 = c.getColumnIndex(RECIPE_NAME);
        int col2 = c.getColumnIndex(RECIPE_DESCRIPTION);
        int col3 = c.getColumnIndex(RECIPE_LEVEL);
        int col4 = c.getColumnIndex(RECIPE_FOOD_TYPE);
        int col5 = c.getColumnIndex(RECIPE_MAKING_TIME);
        int col6 = c.getColumnIndex(RECIPES_PICTURE);
        int col7 = c.getColumnIndex(RECIPE_USER);
        if (c.moveToFirst()) {
            while (!c.isAfterLast()) {
                String sRecipeName = c.getString(col1);
                String sRecipeDescription = c.getString(col2);
                String sRecipeLevel = c.getString(col3);
                String sFoodType = c.getString(col4);
                String sRecipeMakingTime = c.getString(col5);
                Bitmap image = getPicture(c.getBlob(col6));
                String sRecipeUser = c.getString(col7);
                Recipe recipe = new Recipe();
                recipe.setRecipeUser(sRecipeUser);
                recipe.setLevel(sRecipeLevel);
                recipe.setRecipeName(sRecipeName);
                recipe.setFoodType(sFoodType);
                recipe.setRecipeDescription(sRecipeDescription);
                recipe.setImage(image);

                arrayList.add(recipe);
                c.moveToNext();
            }
        }

        c.close();
        sqLiteDatabase.close();
        return arrayList;

    }
    public ArrayList<Recipe>getAllRecipes(){
        ArrayList<Recipe> arrayList= new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
       Cursor c=sqLiteDatabase.query(RECIPES_TABLE, null,null,null,null,null,null);
       int col1=c.getColumnIndex(RECIPE_NAME);
       int col2=c.getColumnIndex(RECIPE_DESCRIPTION);
       int col3=c.getColumnIndex(RECIPE_LEVEL);
       int col4=c.getColumnIndex(RECIPE_FOOD_TYPE);
       int col5=c.getColumnIndex(RECIPE_MAKING_TIME);
       int col6=c.getColumnIndex(RECIPES_PICTURE);
       int col7=c.getColumnIndex(RECIPE_USER);
       c.moveToFirst();
       while (!c.isAfterLast()){
           String sRecipeName=c.getString(col1);
           String sRecipeDescription=c.getString(col2);
           String sRecipeLevel=c.getString(col3);
           String sFoodType=c.getString(col4);
           String sRecipeMakingTime=c.getString(col5);
           Bitmap image=getPicture(c.getBlob(col6));
           String sRecipeUser=c.getString(col7);
           Recipe recipe=new Recipe();
           recipe.setRecipeUser(sRecipeUser);
           recipe.setLevel(sRecipeLevel);
           recipe.setRecipeName(sRecipeName);
           recipe.setFoodType(sFoodType);
           recipe.setRecipeDescription(sRecipeDescription);
           recipe.setImage(image);
           arrayList.add(recipe);
           c.moveToNext();
       }
       sqLiteDatabase.close();
       return arrayList;
    }
    public ArrayList<Recipe> searchRecipe(String foodType, String makingTime) {
        ArrayList<Recipe> arrayList=new ArrayList<>();
        Recipe r=new Recipe();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor c = sqLiteDatabase.query(RECIPES_TABLE, null, RECIPE_FOOD_TYPE + "? AND " + RECIPE_MAKING_TIME + "=?", new String[]{foodType, makingTime}, null, null, null);
        int col1 = c.getColumnIndex(RECIPE_NAME);
        int col2 = c.getColumnIndex(RECIPE_DESCRIPTION);
        int col3 = c.getColumnIndex(RECIPE_LEVEL);
        int col4 = c.getColumnIndex(RECIPE_FOOD_TYPE);
        int col5 = c.getColumnIndex(RECIPE_MAKING_TIME);
        int col6 = c.getColumnIndex(RECIPES_PICTURE);
        int col7 = c.getColumnIndex(RECIPE_USER);
        c.moveToFirst();
        while (!c.isAfterLast()) {
            String sRecipeName = c.getString(col1);
            String sRecipeDescription = c.getString(col2);
            String sRecipeLevel = c.getString(col3);
            String sFoodType = c.getString(col4);
            String sRecipeMakingTime = c.getString(col5);
            String sReceipePicture = c.getString(col6);
            Bitmap image = getPicture(c.getBlob(col6));
            String sRecipeUser = c.getString(col7);
            if (sRecipeUser.equals(makingTime) && sRecipeDescription.equals(foodType)) {
                 r.setRecipeUser(sRecipeUser);
                 r.setLevel(sRecipeLevel);
                 r.setRecipeName(sRecipeName);
                 r.setFoodType(sFoodType);
                 r.setRecipeDescription(sRecipeDescription);
                 r.setImage(image);
                 arrayList.add(r);
                c.moveToNext();
            }
            sqLiteDatabase.close();


        }
        return arrayList;
    }
    private byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream= new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        return stream.toByteArray();
    }
    private Bitmap getPicture(byte[] image){
        return BitmapFactory.decodeByteArray(image,0,image.length);
    }

}
